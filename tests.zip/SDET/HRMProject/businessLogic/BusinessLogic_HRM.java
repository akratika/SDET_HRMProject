package SDET.HRMProject.businessLogic;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import SDET.HRMProject.pageObjects.PageObjects_HRM;

public class BusinessLogic_HRM extends PageObjects_HRM{
	WebDriver driver;
	WebDriverWait wait;
	public BusinessLogic_HRM(WebDriver driver){
		this.driver= driver;
	}
	
	Random random = new Random();
	static String firstNameInput;
	static String lastNameInput;
	static String companyName;
	
	public void waitForElement(String xpathOfElement) {
		wait= new WebDriverWait(driver,60);
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathOfElement)));
		
		}catch(ElementNotVisibleException ex) {
			System.out.println("Element not found:"+xpathOfElement);
		}
	}
	public void verifyTitle() {
		String title = driver.getTitle();		
		if(title.equals("OrangeHRM")) {
			Reporter.log("Title matches OrangeHRM successfully. |");
		}else
			System.out.println("Title is not matching");
	}
	
	public void getlink() {
		
		String headerURL = driver.findElement(By.xpath(headerLogo)).getAttribute("src");
		System.out.println("Header URL: "+ headerURL);
		Reporter.log("Header URL: "+ headerURL +" |");
	}
	
	public void login() {
		//driver.get("http://alchemy.hguy.co/orangehrm"); 	
		driver.findElement(By.xpath(userName)).sendKeys("orange");
		driver.findElement(By.xpath(password)).sendKeys("orangepassword123");
		Reporter.log("credentials entered successfully |");
		driver.findElement(By.xpath(loginButton)).click();
		Reporter.log("Login clicked successfully |");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		if(driver.findElement(By.xpath(dashboardText)).getText().equals("Dashboard")) {
			System.out.println("Dashboard page opened!");
			Reporter.log("Dashboard page opened! |");
		}else
			Reporter.log("Issue opening Dashboard page |");
	}
	
	public void selectTab(String xpathTab, String tabName) {
		driver.findElement(By.xpath(xpathTab)).click();
		Reporter.log(tabName + "tab selected. |");
	}
	
	public void addEmployee() throws InterruptedException {
		
		// waitForElement(addEmployeeButton);
		Thread.sleep(3000);
		driver.findElement(By.xpath(addEmployeeButton)).click();
		//waitForElement(firstNameTextBox);
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		firstNameInput = "Test" + random.nextInt(1000);
		lastNameInput = "Employee" + random.nextInt(1000);
		driver.findElement(By.xpath(firstNameTextBox)).sendKeys(firstNameInput);
		driver.findElement(By.xpath(lastNameTextBox)).sendKeys(lastNameInput);
		driver.findElement(By.xpath(createLoginDetailsCheckbox)).click();
		if(driver.findElement(By.xpath(userNameLabel)).isDisplayed()) {
			driver.findElement(By.xpath(expectedUserName)).sendKeys(firstNameInput);
			driver.findElement(By.xpath(expectedPassword)).sendKeys("Kavin@20");
			driver.findElement(By.xpath(confirmPasswordTextBox)).sendKeys("Kavin@20");
			selectDropdownValue(statusddn, "Enabled");
			Reporter.log("Login credentials entered! |");
		}
		driver.findElement(By.xpath(saveButton)).click();
		
	}
	
	public void searchEmployee() throws InterruptedException {
		// 
		Thread.sleep(4000);
		driver.findElement(By.xpath(adminTab)).click();
		Reporter.log("Admin Tab Clicked |");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//waitForElement(usernameSearchTextox);
		driver.findElement(By.xpath(usernameSearchTextox)).sendKeys(firstNameInput);
		Reporter.log("User name entered |");
		driver.findElement(By.xpath(searchButton_admin)).click();
		Reporter.log("Search Button Clicked |");
		waitForElement(employeeNameColumn);
		List<WebElement> rows = driver.findElements(By.xpath(resultRow));
		if(rows.size() >1) {
			System.out.println("More than one row detected in results!");
			Reporter.log("More than one row detected in results! |");
		}else {
			String employeeName = driver.findElement(By.xpath(employeeNameColumn)).getText();
			if(employeeName.equals(firstNameInput+" "+lastNameInput)) {
				System.out.println("Employee created successfully!");
				Reporter.log("Employee created successfully! |");
			}
		}
	}
	
	public void selectDropdownValue(String locatorpath, String value) {
		WebElement elem = driver.findElement(By.xpath(locatorpath));
		Select select = new Select(elem);
		select.selectByVisibleText(value);
	}
	
	public void datePicker(String selectDateButton, String selectMonthddn, String monthValue, 
			String yearddn, String yearValue, String selectDate, String dateValue) {
		driver.findElement(By.xpath(selectDateButton)).click();
		waitForElement(selectMonthddn);
		selectDropdownValue(selectMonthddn, monthValue);
		selectDropdownValue(yearddn, yearValue);
		driver.findElement(By.xpath(selectDate+dateValue+"']")).click(); 
	}
	
	public void edit_myinfo() throws InterruptedException {
		driver.findElement(By.xpath(myInfoTab)).click();
		waitForElement(editButton);
		driver.findElement(By.xpath(editButton)).click();
		
		//Edit fields
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Thread.sleep(3000);
		driver.findElement(By.xpath(lasNameEdit_myInfo)).clear();
		driver.findElement(By.xpath(lasNameEdit_myInfo)).sendKeys("Employee");
		selectDropdownValue(nationalityddn, "Indian");
		datePicker(selectDateButton+"[2]",selectMonthddn,"Aug",selectYear,"1991",selectDate,"4");
		String genderValue = "Male";
		WebElement gender;
		switch(genderValue) {
		case "Male":
			gender = driver.findElement(By.xpath(genderRadioButton+"1')]"));
			gender.click();
			Reporter.log("Male Selected |");
			break;
		case "Female":
			gender = driver.findElement(By.xpath(genderRadioButton+"2')]"));
			gender.click();
			Reporter.log("Female Selected |");
			break;
		}
		Reporter.log("Details entered under Myinfo. |");
		driver.findElement(By.xpath(saveButton)).click();
	}
	
	public void verifyNavigationMenu() {
		WebElement navigationMenuElem = driver.findElement(By.xpath(navigationMenu));
		if(navigationMenuElem.isDisplayed()) {
			System.out.println("Navigation Menu exists");
			Reporter.log("Navigation Menu exists |");
		}else {
			System.out.println("Navigation Menu doesn't exists");
			Reporter.log("Navigation Menu doesn't exists |");
		}
	}

	public void verifyDirectoryVisible() {
		WebElement directory = driver.findElement(By.xpath(directoryTab));
		if(directory.isDisplayed()) {
			System.out.println("Directory Tab is displayed");
			Reporter.log("Directory Tab is displayed |");
		}else {
			System.out.println("Directory Tab is not displayed");
			Reporter.log("Directory Tab is not displayed |");
		}
		directory.click();
		Reporter.log("Directory Tab clicked |");
	}
	
	public void addQualification() {
		driver.findElement(By.xpath(myInfoTab)).click();
		Reporter.log("MyInfo Tab clicked |");
		waitForElement(qualifications);
		driver.findElement(By.xpath(qualifications)).click();
		Reporter.log("Qualifications clicked |");
		waitForElement(addWorkExperienceButton);
		driver.findElement(By.xpath(addWorkExperienceButton)).click();
		waitForElement(companyTextBox);
		companyName = "IBM" + random.nextInt(100); 
		driver.findElement(By.xpath(companyTextBox)).sendKeys(companyName);
		driver.findElement(By.xpath(jobTitleTextBox)).sendKeys("Automation Tester");
		datePicker(selectDateButton+"[1]", selectMonthddn, "Aug", selectYear, "1991",selectDate , "4");
		driver.findElement(By.xpath(commentTextBox)).sendKeys("Test");
		Reporter.log("Experience details entered |");
		driver.findElement(By.xpath(saveWorkExp)).click();
	}
	
	public boolean isDisplayed(String x_path) {
		try {
			if(driver.findElement(By.xpath(x_path)).isDisplayed()) {
				return true;
			}else
				return false;
		}catch(NoSuchElementException e) {
			return false;
		}
	}
	
	public void applyLeave() throws InterruptedException {
		try {
			if(! isDisplayed(dashboardText)) {
				driver.findElement(By.xpath(dashboardTab)).click();
			}
			if(isDisplayed(dashboardText)) {
				driver.findElement(By.xpath(applyLeaveLink)).click();
				selectDropdownValue(leaveTypeddn, "Paid Leave");
				Reporter.log("Leave Type selected  |");
				
				//From Date
				datePicker(selectDateButton+"[1]", selectMonthddn, "Sep", selectYear, "2020",selectDate , "10");
				
				//To Date
				datePicker(selectDateButton+"[2]", selectMonthddn, "Sep", selectYear, "2020",selectDate , "10");
				
				Thread.sleep(3000);
				driver.findElement(By.xpath(applyButton)).click();
				Reporter.log("Apply Button Clicked  |");
				
				if(isDisplayed(workshiftWarning) == true) {
					System.out.println("Selected Leave exists! Change Dates.");
					Reporter.log("Selected Leave exists! Change Dates. |");
				}
			}
		}catch(ElementNotVisibleException e) {
			System.out.println("Issue in clickApplyLeave method, unable to locate element.");
		}
	}
	
	public void checkLeaveStatus() {
		try {
				//MyLeavePage
				driver.findElement(By.xpath(myLeaveButton)).click();
			
				//From Date
				datePicker(selectDateButton+"[1]", selectMonthddn, "Sep", selectYear, "2020",selectDate , "10");
				
				//To Date
				datePicker(selectDateButton+"[2]", selectMonthddn, "Sep", selectYear, "2020",selectDate , "10");
				
				driver.findElement(By.xpath(searchButton_myleave)).click();
				waitForElement(leaveTypeColumnValue);
				if(driver.findElement(By.xpath(leaveTypeColumnValue)).getText().equals("Paid Leave")) {
					System.out.println("Leave type matched");
					Reporter.log("Leave type matched |");
				}else {
					System.out.println("Leave type not matched");
					Reporter.log("Leave type not matched |");
				}
				if(driver.findElement(By.xpath(leaveStatusColumnValue)).getText().contains("Pending Approval")) {
					System.out.println("Leave status matched");
					Reporter.log("Leave status matched |");
				}else {
					System.out.println("Leave status not matched");
					Reporter.log("Leave status not matched |");
				}
		}catch(ElementNotVisibleException e) {
			System.out.println("Issue in checkLeaveStatus method, unable to locate element.");
			e.printStackTrace();
		}
	}
	
	public void retrieveEmergencyContacts() {
		driver.findElement(By.xpath(myInfoTab)).click();
		waitForElement(emergencyContactsLink);
		driver.findElement(By.xpath(emergencyContactsLink)).click();
		
		//retrieving data from table
		List<WebElement> rows = driver.findElements(By.xpath("//table[@id='emgcontact_list']/tbody/tr"));
		List<ArrayList<String>> rowsData = new ArrayList<ArrayList<String>>();
		
		for(WebElement row: rows) {
			List<WebElement> rowElements = row.findElements(By.tagName("td"));
			ArrayList<String> rowData = new ArrayList<String>();
			for(WebElement column:rowElements) {
				rowData.add(column.getText().toString());
				System.out.println(column.getText()+" , ");
			}
			rowsData.add(rowData);
		}
		
		for(WebElement row: rows) {
			System.out.println(row.toString()+", ");
		}
	}
}
