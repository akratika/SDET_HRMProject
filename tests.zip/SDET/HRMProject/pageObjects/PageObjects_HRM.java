package SDET.HRMProject.pageObjects;

public class PageObjects_HRM {
	
	public static final String headerLogo = "//div[@id='divLogo']/img";
	public static final String userName = "//input[@id='txtUsername']";   // "//span[contains(text(),'Username')]";
	public static final String password = "//input[@id='txtPassword']";
	public static final String loginButton= "//input[@id='btnLogin']";
	public static final String dashboardText = "//div[@class='head']/h1";
	
	public static final String tab_PIM = "//a[@id='menu_pim_viewPimModule']";
	public static final String addEmployeeButton = "//a[@id='menu_pim_addEmployee']";
	public static final String firstNameTextBox = "//input[@id='firstName']";
	public static final String lastNameTextBox = "//input[@id='lastName']";
	public static final String createLoginDetailsCheckbox = "//input[@id='chkLogin']";
	public static final String userNameLabel = "//label[contains(text(),'User Name')]";
	public static final String expectedUserName = "//input[@id='user_name']";
	public static final String expectedPassword = "//input[@id='user_password']";
	public static final String confirmPasswordTextBox = "//input[@id='re_password']";
	public static final String statusddn = "//select[@id='status']";
	public static final String saveButton = "//input[@id='btnSave']";
	
	public static final String adminTab = "//a[@id='menu_admin_viewAdminModule']";
	public static final String usernameSearchTextox = "//input[@id='searchSystemUser_userName']";
	public static final String searchButton_admin = "//input[@id='searchBtn']";
	public static final String resultRow = "//table[@class='table hover']/tbody/tr";
	public static final String employeeNameColumn = "//table[@class='table hover']/tbody/tr/td[4]";
	
	public static final String myInfoTab = "//a[@id='menu_pim_viewMyDetails']";
	public static final String editButton = "//input[@value='Edit']";
	public static final String lasNameEdit_myInfo = "//input[@id='personal_txtEmpLastName']";
	public static final String genderRadioButton = "//input[contains(@id,'personal_optGender_";
	public static final String nationalityddn = "//select[@id='personal_cmbNation']";
	
	public static final String selectDateButton = "(//img[@class='ui-datepicker-trigger'])"; 
	public static final String selectMonthddn = "//select[@class='ui-datepicker-month']";
	public static final String selectYear = "//select[@class='ui-datepicker-year']";
	public static final String selectDate = "//table[@class='ui-datepicker-calendar']/tbody/tr/td/a[text()='";
	public static final String navigationMenu="//div[@class='menu']";
	public static final String directoryTab = "//a[@id='menu_directory_viewDirectory']";
	public static final String searchDirectory = "//div[@class='head']/h1";
	public static final String qualifications = "//div[@id='sidebar']//a[text()='Qualifications']";
	public static final String workExperienceLabel = "//div[@id='sectionWorkExperience']//h1";
	public static final String addWorkExperienceButton = "//input[@id='addWorkExperience']";
	public static final String companyTextBox = "//input[@id='experience_employer']";
	public static final String jobTitleTextBox = "//input[@id='experience_jobtitle']";
	public static final String commentTextBox = "//textarea[@id='experience_comments']";
	public static final String saveWorkExp = "//input[@id='btnWorkExpSave']";
	public static final String dashboardTab = "//a[@id='menu_dashboard_index']";
	public static final String applyLeaveLink = "//span[@class='quickLinkText' and text()='Apply Leave']";
	public static final String leaveTypeddn = "//select[@id='applyleave_txtLeaveType']";
	public static final String applyButton = "//input[@id='applyBtn']";
	public static final String myLeaveButton = "//a[@id='menu_leave_viewMyLeaveList']";
	public static final String searchButton_myleave = "//input[@id='btnSearch']";
	public static final String workshiftWarning = "//h1[contains(text(),'Workshift Length Exceeded')]";
	public static final String leaveTypeColumnValue = "//table[@id='resultTable']//td[3]";
	public static final String leaveStatusColumnValue = "//table[@id='resultTable']//td[6]/a";
	public static final String emergencyContactsLink = "//a[text()='Emergency Contacts']";
	
	
}
