package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
// import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
// import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import SDET.HRMProject.businessLogic.BusinessLogic_HRM;
import SDET.HRMProject.pageObjects.PageObjects_HRM;

public class ActivitiesTestClass {

		WebDriver driver = new ChromeDriver();
		
		BusinessLogic_HRM logic = new BusinessLogic_HRM(driver);
		
		@BeforeClass
		public void driverInstance() {
			driver.get("http://alchemy.hguy.co/orangehrm");
			Reporter.log("URL entered successfully!");
			driver.manage().window().maximize();
		}
		
		@Test(priority=3)
		public void activity1() {
			logic.verifyTitle();
		}
		
		@Test(priority=2)
		public void activity2() {
			logic.getlink();
		}
		
		@Test(priority=0)
		public void activity3() {
			logic.login();
		}
		
		@Test(priority=4)
		public void activity4() throws InterruptedException {
			//logic.login();
			logic.selectTab(PageObjects_HRM.tab_PIM, "PIM");
			logic.addEmployee();
			logic.searchEmployee();
			
		}
		
	
	  @Test(priority=5) 
	  public void activity5() throws InterruptedException { 
		  //logic.login();
		  logic.edit_myinfo();
	  	}
	  
	  @Test(priority=6)
	  public void activity6() { 
		  //logic.login();
		  logic.verifyNavigationMenu();
		  logic.verifyDirectoryVisible();
		}
	  
	  @Test(priority=7)
	  public void activity7() {
		  //logic.login();
		  logic.addQualification();
		}
	  
	  @Test(priority=8)
	  public void activity8() throws InterruptedException {
		  //logic.login();
		  logic.applyLeave();
		  logic.checkLeaveStatus();
		}
	 /*
	  * Issue in the below activity-
	  * Printing the following results in Console instead of text data-
	  * [[ChromeDriver: chrome on WINDOWS (4a9254fda46fd592db49b3faff08489f)] -> xpath: //table[@id='emgcontact_list']/tbody/tr], 
[[ChromeDriver: chrome on WINDOWS (4a9254fda46fd592db49b3faff08489f)] -> xpath: //table[@id='emgcontact_list']/tbody/tr], 
[[ChromeDriver: chrome on WINDOWS (4a9254fda46fd592db49b3faff08489f)] -> xpath: //table[@id='emgcontact_list']/tbody/tr], 
		@method- retrieveEmergencyContacts
	  */
		
	
	  @Test(priority=1)
	  public void activity9() { 
		  //logic.login();
		  logic.retrieveEmergencyContacts();
		}
	 
		@AfterClass
		public void closeBrowser() {
			driver.close();
			Reporter.log("Browser Closed successfully!");
		}


}
