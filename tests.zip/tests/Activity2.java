package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import SDET.HRMProject.businessLogic.BusinessLogic_HRM;
import SDET.HRMProject.pageObjects.PageObjects_HRM;

public class Activity2 {
	
	WebDriver driver = new ChromeDriver();
	
	BusinessLogic_HRM logic = new BusinessLogic_HRM(driver);
	
	@BeforeClass
	public void driverInstance() {
		driver.get("http://alchemy.hguy.co/orangehrm");
		Reporter.log("URL entered successfully!");
		driver.manage().window().maximize();
	}
	
	@Test
	public void activity2() {
		logic.getlink();
	}
	
	@AfterClass
	public void closeBrowser() {
		driver.close();
		Reporter.log("Browser Closed successfully!");
	}



}
